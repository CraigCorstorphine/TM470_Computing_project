package com.craigcorstorphine.tm470_computing_project;

import android.content.DialogInterface;

public interface DialogCloseListner {
    public void handleDialogClose(DialogInterface dialog);
}
